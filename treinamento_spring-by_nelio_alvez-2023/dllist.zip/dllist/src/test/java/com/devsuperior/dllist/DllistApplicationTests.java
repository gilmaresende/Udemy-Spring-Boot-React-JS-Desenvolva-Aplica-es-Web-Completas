package com.devsuperior.dllist;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DllistApplicationTests {

	@Test
	void contextLoads() {
	}

}

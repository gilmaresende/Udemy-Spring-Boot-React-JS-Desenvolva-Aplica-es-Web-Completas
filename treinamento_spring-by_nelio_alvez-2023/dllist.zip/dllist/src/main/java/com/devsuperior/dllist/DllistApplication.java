package com.devsuperior.dllist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DllistApplication {

	public static void main(String[] args) {
		SpringApplication.run(DllistApplication.class, args);
	}

}
